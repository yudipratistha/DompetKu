package com.example.yudipratistha.dompetku.model;

//import javax.annotation.Generated;
import com.google.gson.annotations.SerializedName;

//@Generated("com.robohorse.robopojogenerator")
public class UserLogin{

	@SerializedName("success")
	private Success success;

	@SerializedName("status")
	private boolean status;

	@SerializedName("dataPengguna")
	private DataPengguna dataPengguna;

	public void setSuccess(Success success){
		this.success = success;
	}

	public Success getSuccess(){
		return success;
	}

	public void setStatus(boolean status){
		this.status = status;
	}

	public boolean isStatus(){
		return status;
	}

	public void setDataPengguna(DataPengguna dataPengguna){
		this.dataPengguna = dataPengguna;
	}

	public DataPengguna getDataPengguna(){
		return dataPengguna;
	}

	@Override
 	public String toString(){
		return 
			"UserLogin{" + 
			"success = '" + success + '\'' + 
			",status = '" + status + '\'' + 
			",dataPengguna = '" + dataPengguna + '\'' + 
			"}";
		}
}