package com.example.yudipratistha.dompetku;

import android.content.Intent;
import android.content.SharedPreferences;
import android.os.Bundle;
import android.support.annotation.NonNull;
import android.support.design.widget.BottomNavigationView;
import android.support.v7.app.AppCompatActivity;
import android.view.MenuItem;
import android.widget.TextView;

import com.example.yudipratistha.dompetku.API.APIClient;
import com.example.yudipratistha.dompetku.API.APIService;


public class MainActivity extends AppCompatActivity {
    protected TextView nama_pengguna, email_pengguna;

    APIService service;

    @Override
    protected void onCreate(Bundle savedInstanceState) {
        super.onCreate(savedInstanceState);
        setContentView(R.layout.activity_main);

        service = APIClient.getService();
//
        nama_pengguna = findViewById(R.id.input_name);
        email_pengguna = findViewById(R.id.input_email);

        SharedPreferences sharedPreferences = getSharedPreferences("dataPengguna", MODE_PRIVATE);
        Boolean status_login = sharedPreferences.getBoolean("status_login",false);
        String nama_user = sharedPreferences.getString("nama_user","");
        String email_user = sharedPreferences.getString("email_user", "");
//
//        nama_pengguna.setText(nama_user);
//        email_pengguna.setText(email_user);

//        Intent intent = new Intent(this, LoginActivity.class);
//        startActivity(intent);

        BottomNavigationView bottomNavigationView = (BottomNavigationView)
                findViewById(R.id.bottom_navigation);

        bottomNavigationView.setOnNavigationItemSelectedListener(
                new BottomNavigationView.OnNavigationItemSelectedListener() {
                    @Override
                    public boolean onNavigationItemSelected(@NonNull MenuItem item) {
                        switch (item.getItemId()) {
                            case R.id.action_favorites:

                            case R.id.action_schedules:

                            case R.id.action_music:

                        }
                        return true;
                    }
                });
    }
}
