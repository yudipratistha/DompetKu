package com.example.yudipratistha.dompetku.API;


public interface APIService {

}